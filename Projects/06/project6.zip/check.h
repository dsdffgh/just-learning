//
// Created by name on 2023/11/7.
//

#ifndef ASSEMBLER_CHECK_H
#define ASSEMBLER_CHECK_H

#include <stdio.h>
#include <string.h>

#define MAX_LINE_LENGTH 20

int check(char *file_check1, char *file_check2, FILE *checkout);

#endif //ASSEMBLER_CHECK_H
